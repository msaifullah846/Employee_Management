from django.contrib import admin

# Register your models here.
from .models import Employee

class Employee_Admin(admin.ModelAdmin):
    list_display=('image','name','gender','email','department','designation','salary')


admin.site.register(Employee,Employee_Admin)