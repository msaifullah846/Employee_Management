from django.db import models

class Employee(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    DEPARTMENT_CHOICES =[
        ('F','FINANCE'),
        ('S','SALES'),
        ('E','EDUCATION')
    ]

    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    email = models.EmailField(unique=True)
    department = models.CharField(max_length=1,choices=DEPARTMENT_CHOICES)
    designation = models.CharField(max_length=100)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='employee_images/')

    def __str__(self):
        return self.name
